# -*- coding: utf-8 -*-
import sys

if __name__ == '__main__':
    from conda_env.cli.main import main
    sys.exit(main())
